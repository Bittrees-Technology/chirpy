/**
 * Pre-configured URLs for the XMTP network based on the environment
 *
 * @deprecated Use `createBackend()` instead.
 * @constant
 * @property {string} local - The local URL for the XMTP network
 * @property {string} dev - The development URL for the XMTP network
 * @property {string} production - The production URL for the XMTP network
 */
export const ApiUrls = {
  local: "http://localhost:5557",
  dev: "https://api.dev.xmtp.network:5558",
  production: "https://api.production.xmtp.network:5558",
} as const;

/**
 * Pre-configured URLs for the XMTP history sync service based on the environment
 *
 * @constant
 * @property {string} local - The local URL for the XMTP history sync service
 * @property {string} dev - The development URL for the XMTP history sync service
 * @property {string} production - The production URL for the XMTP history sync service
 */
export const HistorySyncUrls = {
  local: "http://localhost:5558",
  dev: "https://message-history.dev.ephemera.network",
  production: "https://message-history.production.ephemera.network",
  "testnet-staging": "https://message-history.dev.ephemera.network",
  "testnet-dev": "https://message-history.dev.ephemera.network",
  testnet: "https://message-history.dev.ephemera.network",
  mainnet: "https://message-history.production.ephemera.network",
} as const;
