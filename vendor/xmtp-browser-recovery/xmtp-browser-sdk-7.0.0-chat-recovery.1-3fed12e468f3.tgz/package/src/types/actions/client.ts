import type {
  ArchiveMetadata,
  ArchiveOptions,
  AvailableArchiveInfo,
  GroupSyncSummary,
  Identifier,
  KeyPackageStatus,
} from "@xmtp/wasm-bindings";
import type { ClientOptions } from "@/types/options";
import type { SafeSigner } from "@/utils/signer";

export type ClientAction =
  | {
      action: "client.init";
      id: string;
      result: {
        appVersion: string;
        env: string;
        inboxId: string;
        installationId: string;
        installationIdBytes: Uint8Array;
        libxmtpVersion: string;
      };
      data: {
        identifier: Identifier;
        options?: ClientOptions;
      };
    }
  | {
      action: "client.applySignatureRequest";
      id: string;
      result: undefined;
      data: {
        signer: SafeSigner;
        signatureRequestId: string;
      };
    }
  | {
      action: "client.createInboxSignatureText";
      id: string;
      result: {
        signatureText?: string;
        signatureRequestId?: string;
      };
      data: {
        signatureRequestId: string;
      };
    }
  | {
      action: "client.addAccountSignatureText";
      id: string;
      result: {
        signatureText: string;
        signatureRequestId: string;
      };
      data: {
        newIdentifier: Identifier;
        signatureRequestId: string;
      };
    }
  | {
      action: "client.removeAccountSignatureText";
      id: string;
      result: {
        signatureText: string;
        signatureRequestId: string;
      };
      data: {
        identifier: Identifier;
        signatureRequestId: string;
      };
    }
  | {
      action: "client.revokeAllOtherInstallationsSignatureText";
      id: string;
      result: {
        signatureText: string | undefined;
        signatureRequestId: string;
      };
      data: {
        signatureRequestId: string;
      };
    }
  | {
      action: "client.revokeInstallationsSignatureText";
      id: string;
      result: {
        signatureText: string;
        signatureRequestId: string;
      };
      data: {
        installationIds: Uint8Array[];
        signatureRequestId: string;
      };
    }
  | {
      action: "client.changeRecoveryIdentifierSignatureText";
      id: string;
      result: {
        signatureText: string;
        signatureRequestId: string;
      };
      data: {
        identifier: Identifier;
        signatureRequestId: string;
      };
    }
  | {
      action: "client.registerIdentity";
      id: string;
      result: undefined;
      data: {
        signer: SafeSigner;
        signatureRequestId: string;
      };
    }
  | {
      action: "client.addAccount";
      id: string;
      result: undefined;
      data: {
        identifier: Identifier;
        signer: SafeSigner;
        signatureRequestId: string;
      };
    }
  | {
      action: "client.removeAccount";
      id: string;
      result: undefined;
      data: {
        identifier: Identifier;
        signer: SafeSigner;
        signatureRequestId: string;
      };
    }
  | {
      action: "client.revokeAllOtherInstallations";
      id: string;
      result: undefined;
      data: {
        signer: SafeSigner;
        signatureRequestId: string;
      };
    }
  | {
      action: "client.changeRecoveryIdentifier";
      id: string;
      result: undefined;
      data: {
        identifier: Identifier;
        signer: SafeSigner;
        signatureRequestId: string;
      };
    }
  | {
      action: "client.revokeInstallations";
      id: string;
      result: undefined;
      data: {
        installationIds: Uint8Array[];
        signer: SafeSigner;
        signatureRequestId: string;
      };
    }
  | {
      action: "client.isRegistered";
      id: string;
      result: boolean;
      data: undefined;
    }
  | {
      action: "client.canMessage";
      id: string;
      result: Map<string, boolean>;
      data: {
        identifiers: Identifier[];
      };
    }
  | {
      action: "client.getInboxIdByIdentifier";
      id: string;
      result: string | undefined;
      data: {
        identifier: Identifier;
      };
    }
  | {
      action: "client.signWithInstallationKey";
      id: string;
      result: Uint8Array;
      data: {
        signatureText: string;
      };
    }
  | {
      action: "client.verifySignedWithInstallationKey";
      id: string;
      result: boolean;
      data: {
        signatureText: string;
        signatureBytes: Uint8Array;
      };
    }
  | {
      action: "client.verifySignedWithPublicKey";
      id: string;
      result: boolean;
      data: {
        signatureText: string;
        signatureBytes: Uint8Array;
        publicKey: Uint8Array;
      };
    }
  | {
      action: "client.fetchKeyPackageStatuses";
      id: string;
      result: Map<string, KeyPackageStatus>;
      data: {
        installationIds: string[];
      };
    }
  | {
      action: "client.sendSyncRequest";
      id: string;
      result: undefined;
      data: {
        options: ArchiveOptions;
        serverUrl: string;
      };
    }
  | {
      action: "client.sendSyncArchive";
      id: string;
      result: undefined;
      data: {
        options: ArchiveOptions;
        serverUrl: string;
        pin: string;
      };
    }
  | {
      action: "client.processSyncArchive";
      id: string;
      result: undefined;
      data: {
        archivePin?: string | null;
      };
    }
  | {
      action: "client.listAvailableArchives";
      id: string;
      result: AvailableArchiveInfo[];
      data: {
        daysCutoff: number;
      };
    }
  | {
      action: "client.createArchive";
      id: string;
      result: Uint8Array;
      data: {
        opts: ArchiveOptions;
        key: Uint8Array;
      };
    }
  | {
      action: "client.importArchive";
      id: string;
      result: undefined;
      data: {
        data: Uint8Array;
        key: Uint8Array;
      };
    }
  | {
      action: "client.archiveMetadata";
      id: string;
      result: ArchiveMetadata;
      data: {
        data: Uint8Array;
        key: Uint8Array;
      };
    }
  | {
      action: "client.syncAllDeviceSyncGroups";
      id: string;
      result: GroupSyncSummary;
      data: undefined;
    };
